"""Joint flow Taylor remainder and global parameter-family local Gamma bounds."""
from pathlib import Path
from fractions import Fraction as F
import json,time,hashlib,numpy as np
import interval_taylor as t
from interval_flow import flow_map
OUT=Path(__file__).resolve().parent
source=json.loads((OUT/'inflated_structured_noise_Q_taylor_bounds.json').read_text())
r=source['state_component_radii_binary64_outward'];ep=.005;ev=.01
controller,_,_=t.backup_map(r,ep,ev,0,structured_controller=True)
# Capture actual validated controller deviation bounds, not sampled commands or
# a point gain. Rational decimal ceilings make the declared SI box explicit.
command_exact=list(map(F,['.115898','.223855','.223855','.024254336']))
u=[t.outer(x,True) for x in command_exact];joint=r+u+[0.,0.];d=list(map(t.frac,joint));rows=[];signed={}
print('command_deviation_SI_box',u,flush=True)
for branch in (0,1):
 start=time.monotonic()
 try:
  output,checks,p=flow_map(r,u,branch)
  H=np.array([x.h.absmax() for x in output]);eps=[]
  for i in range(21):eps.append(t.outer(sum((t.frac(H[i,j,k])*d[j]*d[k]/2 for j in range(25) for k in range(25)),F(0)),True))
  zero,zero_checks,_=flow_map([0.]*21,[0.]*4,branch)
  gamma_lo=np.array([x.g.lo[21:25] for x in zero]);gamma_hi=np.array([x.g.hi[21:25] for x in zero])
  # Exact causal/queue structure removes only analytically zero entries.
  allowed={0:{2,5,12,13},1:{1,4,6,9,14},2:{0,3,7,10,15},3:{8,11,16}}
  for i in range(21):
   for j in range(4):
    if i not in allowed[j] or branch==1:gamma_lo[i,j]=gamma_hi[i,j]=0.
  gamma_lo[13:17]=np.eye(4);gamma_hi[13:17]=np.eye(4)
  for suffix,arr in [('H_lower',[x.h.lo for x in output]),('H_upper',[x.h.hi for x in output]),('J_lower',[x.g.lo for x in output]),('J_upper',[x.g.hi for x in output])]:signed[f'branch{branch}_{suffix}']=np.array(arr)
  row={'branch':branch,'status':'conditional_real_joint_flow_hessian_domain_pass','epsilon_joint_state_command':eps,
       'local_Gamma_parameter_interval_lower':gamma_lo.tolist(),'local_Gamma_parameter_interval_upper':gamma_hi.tolist(),
       'zero_origin_checks':zero_checks,'branch_domain_checks':checks,'elapsed_s':time.monotonic()-start}
  print(branch,'flow_epsmax',max(eps),'motor_queue_eps',eps[12:],'sec',row['elapsed_s'],flush=True)
 except t.DomainFailure as e:row={'branch':branch,'status':'domain_failure','reason':str(e)}
 rows.append(row)
np.savez_compressed(OUT/'inflated_narrow_joint_flow_derivative_intervals.npz',**signed)
result={'scope':'REAL physical flow with independent public SI new-command input; controller NL/noise propagated through localGamma ONCE, plus this joint flow remainder. Not a machine execution or RPI certificate.',
        'flight_certificate':False,'machine_execution_budget_proved':False,
        'source_controller_bounds':{'path':str(OUT/'inflated_structured_noise_Q_taylor_bounds.json'),'sha256':hashlib.sha256((OUT/'inflated_structured_noise_Q_taylor_bounds.json').read_bytes()).hexdigest()},
        'command_domain_provenance':'Exact inflated-Q linear-form supports plus proved joint27D structured-H remainder and linear noise bounds; assess_phase4 external companion audit.',
        'state_radii':r,'command_deviation_radii_exact':[str(x) for x in command_exact],'command_deviation_radii_binary64_outward':u,
        'input_order':'state0..20, new SI command deviations21..24,unused25..26','runs':rows,
        'source_sha256':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ['interval_flow.py','run_inflated_narrow_flow.py','interval_taylor.py']}}
(OUT/'inflated_narrow_joint_flow_bounds.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
